#ifndef STRING_H
#define STRING_H
#include <stdexcept>
#include <cstring>
#include <iostream>

class StringOutOfRange : public std::out_of_range {
 public:
  StringOutOfRange() : std::out_of_range("StringOutOfRange") {
  }
};

class String {
private:
  char* buffer_;
  size_t size_;
  size_t capacity_;
public:
  String();
  String(const char* str); //NOLINT
  String(const char* str, size_t n);
  String(const String& other);
  String(size_t n, char el);
  String& operator=(const String& str);
  ~String();
  const char& operator[](size_t num) const;
  char& operator[](size_t num);
  char& At(size_t num);
  const char& At(size_t num) const;
  char& Front();
  const char& Front() const;
  char& Back();
  const char& Back() const;
  const char* Data() const;
  char* CStr();
  bool Empty() const;
  size_t Size() const;
  size_t Capacity() const;
  size_t Length() const;
  void Clear();
  void Swap(String& other);
  void PopBack();
  void PushBack(char str);
  String& operator+=(const String& other);
  void Resize(size_t new_size, const char symbol);
  void Reserve(size_t new_capacity);
  void ShrinkToFit();
  friend bool operator==(const String& str1, const String& str2);
  friend bool operator!=(const String& str1, const String& str2);
  friend bool operator<(const String& str1, const String& str2);
  friend bool operator>(const String& str1, const String& str2);
  friend bool operator<=(const String& str1, const String& str2);
  friend bool operator>=(const String& str1, const String& str2); 
  friend String operator+(const String& a, const String& b);
  friend std::ostream &operator<<(std::ostream &os, const String& string);
};


#endif