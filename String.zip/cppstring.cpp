#include "cppstring.h"

String::String() : buffer_(nullptr), size_(0), capacity_(0) {}

String::String(const char* str) {
  size_ = strlen(str);
  capacity_ = size_;
  buffer_ = new char[capacity_ + 1];
  stpncpy(buffer_, str, size_);
}

String::String(const char* str, size_t n) {
  size_ = n;
  capacity_ = n;
  buffer_ = new char[n];
  stpncpy(buffer_, str, size_);
}

String::String(size_t n, char el) {
  size_ = n;
  capacity_ = n;
  if (n == 0) {
    buffer_ = nullptr; 
  } else {
    buffer_ = new char[n];
    for (size_t i = 0; i < n; i++) {
      buffer_[i] = el;
    }
  }
}

String::String(const String& other) {
  size_ = other.size_;
  capacity_ = other.capacity_;
  if (other.buffer_ == nullptr) {
    buffer_ = nullptr;
  } else {
    buffer_ = new char[other.capacity_];
    strncpy(buffer_, other.buffer_, other.size_);
  }
}

size_t String::Length() const{
  return size_;
}

String::~String() {
  delete[] this->buffer_;
}

const char* String::Data() const {
  return buffer_;
}

char* String::CStr() {
  return buffer_;
}

size_t String::Capacity() const {
  return capacity_;
}

size_t String::Size() const {
  return size_;
}

String& String::operator=(const String& str) {
  if (this == &str) {
    return *this;
  }
  delete[] buffer_;
  if (str.Data() != nullptr) {
    auto source = str.Data();
    buffer_ = new char[str.Capacity()];
    size_ = str.Size();
    capacity_ = str.Capacity();
    for (size_t i = 0; i < str.Size(); i++) {
      buffer_[i] = source[i];
    }
  } else {
    buffer_ = nullptr;
  }
  return *this;
}

const char& String::operator[](size_t num) const {
  return buffer_[num - 1];
}

char& String::operator[](size_t num) {
  return buffer_[num - 1];
}

void String::Clear() {
  for (size_t i = 0; i < size_; i++) {
    buffer_[i] = '\0';
  }
  size_ = 0;
}

void String::Swap(String& other) {
  size_t tmp = size_;
  size_ = other.size_;
  other.size_ = tmp;
  size_t tmp1 = this->capacity_;
  capacity_ = other.capacity_;
  other.capacity_ = tmp1;
  std::swap(buffer_, other.buffer_);
}

char& String::At(size_t num) {
  if (size_ < num) {
    throw StringOutOfRange();
  }
  return buffer_[num - 1];
}

const char& String::At(size_t num) const {
  if (size_ < num) {
    throw StringOutOfRange();
  }
  return buffer_[num - 1];
}

const char& String::Front() const {
  return buffer_[0];
}

char& String::Front() {
  return buffer_[0];
}

const char& String::Back() const {
  return buffer_[size_ - 1];
}

char& String::Back() {
  return buffer_[size_ - 1];
}

void String::PopBack() {
  buffer_[size_ - 1] = '\0';
  --size_;
}

void String::PushBack(char str) {
  if (capacity_ > size_) {
    buffer_[size_] = str;
    size_++;
    return;
  }
  auto new_buff = new char[capacity_ == 0 ? 1 : capacity_ * 2];
  stpncpy(new_buff, buffer_, size_);
  delete[] buffer_;
  new_buff[size_] = str;
  buffer_ = new_buff;
  size_++;
  capacity_ = (capacity_ == 0 ? 1 : capacity_ * 2);
}

String& String::operator+=(const String& other) {
  if (size_ + other.Size() <= capacity_) {
    strcat(buffer_, other.buffer_);
    size_ += other.Size();
    return *this;
  }
  auto new_buff = new char[size_ + other.Size()];
  stpncpy(new_buff, buffer_, size_);
  delete[] buffer_;
  buffer_ = new_buff;
  strcat(buffer_, other.Data());
  capacity_ = size_ + other.Size();
  size_ += other.Size();
  return *this;
}

void String::Resize(size_t new_size, char symbol) {
  if (size_ > new_size) {
    for (size_t i = new_size; i < size_ - new_size; i++) {
      buffer_[i] = '\0';
    }
    size_ = new_size;
  }
  if (capacity_ < new_size) {
    auto new_buff = new char[new_size];
    stpncpy(new_buff, buffer_, size_);
    delete[] buffer_;
    buffer_ = new_buff;
    capacity_ = new_size;
  }
  for (size_t i = size_; i < new_size; i++) {
    buffer_[i] = symbol;
  }
  size_ = new_size;
}

void String::Reserve(size_t new_capacity) {
  size_t max = std::max(capacity_, new_capacity);
  if (max == capacity_) {
    return;
  }
  auto new_buff = new char[new_capacity];
  stpncpy(new_buff, buffer_, size_);
  delete[] buffer_;
  buffer_ = new_buff;
  capacity_ = new_capacity;
}

void String::ShrinkToFit() {
  if (size_ < capacity_) {
    if (size_ == 0) {
      delete[] buffer_;
      buffer_ = nullptr;
      return;
    }
    auto new_buff = new char[size_];
    stpcpy(new_buff, buffer_);
    delete[] buffer_;
    buffer_ = new_buff;
    capacity_ = size_;
  }
}

String operator+(const String& a, const String& b) {
  String c;
  c.Reserve(a.Size() + b.Size());
  c += a;
  c += b;
  return c;
}

std::ostream &operator<<(std::ostream &os, const String& string) {
  for (size_t i = 0; i < string.size_; i++) {
    os << string.buffer_[i];
  }
  return os;
}

bool String::Empty() const {
  return (size_ == 0);
}

bool operator==(const String& str1, const String& str2) {
  if (str1.Size() != str2.Size()) {
    return false;
  }
  for (size_t i = 0; i < str1.Size(); ++i) {
    if (str1[i] != str2[i]) {
      return false;
    }
    return true;
  }
  return false;
}
bool operator!=(const String& str1, const String& str2) {
  return !(str1 == str2);
}
bool operator<(const String& str1, const String& str2) {
  if (str1.Size() < str2.Size()) {
    return true;
  }
  if (str1.Size() > str2.Size()) {
    return false;
  }
  for (size_t i = 0; i < str1.Size(); ++i) {
    if (str1[i] < str2[i]) {
      return true;
    }
    if (str1[i] > str2[i]) {
      return false;
    }
  }
  return false;
}

bool operator>(const String& str1, const String& str2) {
  if (str1 < str2) {
    return false;
  }
  return !(str1 == str2);
}

bool operator<=(const String& str1, const String& str2) {
  return (str1 == str2 or str1 < str2);
}
bool operator>=(const String& str1, const String& str2) {
  return (str1 == str2 or str1 > str2);
}

int main() {
  String s(3, 'a');
  std::cout << s;
}