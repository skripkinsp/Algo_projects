#ifndef LINE_H
#define LINE_H
#include "ishape.h"
namespace geometry {
  class Line : public IShape{
  public:
    int a;
    int b;
    int c;
    Point zatychka;
    Line();
    Line(const Point&, const Point&);
    Line(const Point&, const Vector&);
    ~Line() override;
    Line& Move(const Vector&) override;
    Line* Clone() const override;
    std::string ToString() const override;
    bool ContainsPoint(const Point&) const override;
    bool CrossesSegment(const Segment&) const override;
  };
}

#endif