#ifndef POLYGON_H
#define POLYGON_H
#include "ishape.h"
#include <vector>
namespace geometry {
  class Polygon : public IShape {
  public:
    std::vector<Point> points;
    Polygon();
    explicit Polygon(std::vector<Point>);
    ~Polygon() override;
    Polygon& Move(const Vector&) override;
    bool ContainsPoint(const Point&) const override;
    bool CrossesSegment(const Segment&) const override;
    Polygon* Clone() const override;
    std::string ToString() const override;
  };
}

#endif