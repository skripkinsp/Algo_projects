#include <iostream>
#include <string>
#include <vector>
#include <cmath>
#include <memory>
#include "../ishape.h"
#include "../vector.h"
#include "../point.h"
#include "../line.h"
#include "../ray.h"
#include "../segment.h"
#include "../polygon.h"
#include "../circle.h"

namespace geometry{
  int64_t VectorProduct(const Vector& v1, const Vector& v2) {
    return v1.x * v2.y - v2.x * v1.y;
  }

  int64_t ScalarProduct(const Vector& v1, const Vector& v2) {
    return v1.x * v2.x + v1.y * v2.y;
  }
  bool IsParrallel(const Line& l1, const Line& l2) {
    return l1.a * l2.b == l1.b * l2.a;
  }
  
  Point Cross(const Line& l1, const Line& l2) {
    int x = (l1.b * l2.c - l1.c * l2.b) / (l1.a * l2.b - l1.b * l2.a);
    int y = (l1.a * l2.c - l1.c * l2.a) / (l1.b * l2.a - l2.b * l1.a);
    Point c(x, y);
    return c;
  }

  Vector::Vector() : x(0), y(0) {
  }

  Vector::Vector(int x, int y) : x(x), y(y) {
  }

  Vector::Vector(const Point& a, const Point& b) {
    x = b.x - a.x;
    y = b.y - a.y;
  }

  Vector Vector::operator+(const Vector& other) {
    Vector v(x + other.x, y + other.y);
    return v;
  }

  Vector Vector::operator-(const Vector& other) {
    Vector v(x - other.x, y - other.y);
    return v; 
  }

  Vector Vector::operator+() {
    Vector v(x, y);
    return v;
  }

  Vector Vector::operator-() {
    Vector v(((-1) * x), (y * (-1)));
    return v;
  }

  Vector& Vector::operator+=(const Vector& other) {
    x += other.x;
    y += other.y;
    return *this;
  }

  Vector& Vector::operator-=(const Vector& other) {
    x -= other.x;
    y -= other.y;
    return *this;
  }

  Vector& Vector::operator*=(int num) {
    x *= num;
    y *= num;
    return *this;
  }

  Vector& Vector::operator/=(int num) {
    x /= num;
    y /= num;
    return *this;
  }

  Vector Vector::operator*(int num) {
    Vector v(x * num, y * num);
    return v;
  }
  
  Vector Vector::operator/(int num) {
    Vector v(x / num, y / num);
    return v;
  }

  Vector operator*(int n, const Vector& v) {
    return Vector(v.x * n, v.y * n);
  }

  bool operator==(const Vector& v1, const Vector& v2) {
    return ((v1.x * v2.y) == (v1.y * v2.x));
  }

  bool operator!=(const Vector& other1, const Vector& other2) {
    return !(other1 == other2);
  }

  std::string Vector::ToString() const {
    std::string str = "Vector(" + std::to_string(x) + ", " + std::to_string(y) + ")";
    return str;
  }

  Point::Point() : x(0), y(0) {
  }

  Point::Point(int x, int y) : x(x), y(y) {
  }

  Point& Point::Move(const Vector& v) {
    x += v.x;
    y += v.y;
    return *this;
  }

  Point* Point::Clone() const {
    auto point = new Point;
    point->x = x;
    point->y = y;
    return point;
  }

  std::string Point::ToString() const {
    std::string str = "Point(" + std::to_string(x) + ", " + std::to_string(y) + ")";
    return str;
  }

  Vector operator-(const Point& a, const Point& b) {
    return Vector(a.x - b.x, a.y - b.y);
  }

  Vector& Vector::operator=(const Vector& another) = default;
  bool Point::ContainsPoint(const Point& p) const{
    return((p.x == x) && (p.y == y));
  }

  bool Point::CrossesSegment(const Segment& s) const {
    Vector seg1(s.p1, *this);
    Vector seg2(*this, s.p2);
    return((ScalarProduct(seg1, seg2) >= 0) && (VectorProduct(seg1, seg2) == 0));
  }

  Segment::Segment() : p1(Point()), p2(Point()) {
  }

  Segment::Segment(Point a, Point b) : p1(a), p2(b) {
  }

  Segment* Segment::Clone() const {
    auto segment = new Segment;
    *segment = *this;
    return segment;
  }

  Segment& Segment::Move(const Vector& v) {
    p1.Move(v);
    p2.Move(v);
    return *this;
  }

  std::string Segment::ToString() const {
    std::string str = "Segment(" + p1.ToString() + ", " + p2.ToString() + ")";
    return str;
  }

  bool Segment::ContainsPoint(const Point& p) const {
    return p.CrossesSegment(*this);
  }

  bool Segment::CrossesSegment(const Segment& s) const {
    Vector v1(p1, p2);
    Vector v2(s.p1, s.p2);
    Vector vs11(p1, s.p1);
    Vector vs12(p1, s.p2);
    int64_t pointer1;
    pointer1 = VectorProduct(v1, vs11) * VectorProduct(v1, vs12);
    Vector vs21(s.p1, p1);
    Vector vs22(s.p1, p2);
    int64_t pointer2;
    pointer2 = VectorProduct(v2, vs21) * VectorProduct(v2, vs22);
    if ((VectorProduct(v1, vs11) == 0) && (VectorProduct(v1, vs12) == 0) && (VectorProduct(v2, vs21) == 0) && (VectorProduct(v2, vs22) == 0)) {
      return ((this->ContainsPoint(s.p1)) || (this->ContainsPoint(s.p2)) || s.ContainsPoint(this->p1) || s.ContainsPoint(this->p2));
    }
    return ((pointer1 <= 0) && (pointer2 <= 0));
  }

  Ray::Ray() : begin(Point()), direct(Vector()) {
  }

  Ray::Ray(const Point& p1, const Point& p2) : begin(p1), direct(Vector(p1, p2)) {
  }

  Ray::Ray(const Point& p, const Vector& v) : begin(p), direct(v) {
  }

  Ray& Ray::Move(const Vector& v) {
    begin.Move(v);
    return *this;
  }

  Ray* Ray::Clone() const {
    auto ray = new Ray;
    *ray = *this;
    return ray;
  }

  std::string Ray::ToString() const {
    std::string str = "Ray(" + begin.ToString() + ", " + direct.ToString() + ")";
    return str;
  }

  bool Ray::ContainsPoint(const Point& p) const {
    int sp = ScalarProduct(Vector(begin, p), direct);
    return (VectorProduct(Vector(begin, p), direct) == 0 && sp >= 0);
  }

  Line::Line() : a(0), b(0), c(0) {
  }

  Line::Line(const Point& p1, const Point& p2) {
    a = p2.y - p1.y;
    b = p1.x - p2.x;
    c = ((-1) * ((a * p2.x) + (b * p2.y)));
    zatychka = p1;
  }

  Line::Line(const Point& p, const Vector& v) {
    a = (-1) * v.y;
    b = v.x;
    c = (-1) * (a * p.x + b * p.y);
    zatychka = p;
  }

  Line& Line::Move(const Vector& v) {
    zatychka.Move(v);
    c = (-1) * (zatychka.x * a + zatychka.y * b);
    return *this;
  }

  Line* Line::Clone() const {
    auto line = new Line;
    *line = *this;
    return line;
  }

  std::string Line::ToString() const {
    std::string str = "Line(" + std::to_string(a) + ", " + std::to_string(b) + ", " + std::to_string(c) + ")";
    return str;
  }

  bool Line::ContainsPoint(const Point& p) const {
    return (p.x * a + p.y * b + c == 0);
  }

  bool Line::CrossesSegment(const Segment& s) const {
    int64_t n = s.p1.x * a + s.p1.y * b + c;
    int64_t m = s.p2.x * a + s.p2.y * b + c;
    return (n * m <= 0);
  }

  bool Ray::CrossesSegment(const Segment& s) const {
    if ((this->ContainsPoint(s.p1)) || (this->ContainsPoint(s.p2))) {
      return true;
    }
    Line ln(begin, direct);
    bool cross = ln.CrossesSegment(s);
    Vector ao(s.p1, begin);
    Vector ab(s.p1, s.p2);
    return((VectorProduct(ao, ab) * VectorProduct(direct, ab)) < 0 && cross);
  }
  
  Polygon::Polygon() = default;
   
  Polygon::Polygon(std::vector<Point> vct) : points(vct) {
  }

  Polygon& Polygon::Move(const Vector& v) {
    for (size_t i = 0; i < points.size(); i++) {
      points[i].Move(v);
    }
    return *this;
  }

  bool Polygon::ContainsPoint(const Point& p) const {
    int sum = 0;
    int x_move = p.x;
    int y_move = p.y;
    Point p_copy;
    size_t size = points.size();
    auto points_copy = new Point[size];
    for (size_t i = 0; i < size; i++) {
      points_copy[i].x = points[i].x - x_move;
      points_copy[i].y = points[i].y - y_move;
      if ((points_copy[i].x == 0) && (points_copy[i].y == 0)) {
        delete[] points_copy;
        return true;
      }
    }
    Point p1(1, 0);
    Ray r(p_copy, p1);
    Segment s;
    for (size_t i = 0; i < size; i++) {
      if (i == size - 1) {
        s = Segment(points_copy[size - 1], points_copy[0]);
      } else {
        s = Segment(points_copy[i], points_copy[i + 1]);
      }
      if (r.CrossesSegment(s)) {
        if (s.ContainsPoint(p_copy)) {
          delete[] points_copy;
          return true;
        }
        bool is_a = r.ContainsPoint(s.p1);
        bool is_b = r.ContainsPoint(s.p2);
        if (is_a && is_b) {
          sum += 0;
        }
        if (is_a && (s.p1.y > s.p2.y)) {
          sum += 1;
        }
        if (is_b && (s.p2.y > s.p1.y)) {
          sum += 1;
        }
        if (!(is_a) && !(is_b)) {
          sum += 1;
        }
      }
    }
    delete[] points_copy;
    return (sum % 2 == 1);
  }

  bool Polygon::CrossesSegment(const Segment& s) const {
    for (size_t i = 0; i < points.size() - 1; i++) {
      Segment s1(points[i], points[i + 1]);
      if (s.CrossesSegment(s1)) {
        return true;
      }
    }
    Segment s1(points.back(), points[0]);
    return (s.CrossesSegment(s1));
  }

  Polygon* Polygon::Clone() const {
    auto pol = new Polygon;
    *pol = *this;
    return pol;
  }

  std::string Polygon::ToString() const {
    std::string str = "Polygon(";
    for (size_t i = 0; i < points.size() - 1; ++i) {
      str += points[i].ToString() + ", ";
    }
    str += points[points.size() - 1].ToString() + ")";
    return str;
  }

  Circle::Circle() : radius(0), centre(Point()) {
  }

  Circle::Circle(const Point& p, int n) : radius(n), centre(p) {
  }

  Circle& Circle::Move(const Vector& v) {
    centre.Move(v);
    return *this;
  }

  Circle* Circle::Clone() const {
    auto cir = new Circle;
    *cir = *this;
    return cir;
  }

  std::string Circle::ToString() const {
    std::string str = "Circle(" + centre.ToString() + ", " + std::to_string(radius) + ")";
    return str;
  }

  bool Circle::ContainsPoint(const Point& p) const {
    return ((p.x - centre.x) * (p.x - centre.x) + (p.y - centre.y) * (p.y - centre.y) <=
            (radius * radius));
  }

  bool Circle::OnAreol(const Point& p) const {
    return ((p.x - centre.x) * (p.x - centre.x) + (p.y - centre.y) * (p.y - centre.y) ==
            (radius * radius));
  }

  bool Circle::CrossesSegment(const Segment& s) const {
    int64_t dis;
    if ((s.p1.x * s.p1.x) + (s.p1.y * s.p1.y) < radius * radius &&
        (s.p2.x * s.p2.x) + (s.p2.y * s.p2.y) < radius * radius) {
      return false;  
    }
    Vector v1 = centre - s.p1;
    Vector v2 = centre - s.p2;
    Vector dir(s.p1, s.p2);
    if (ScalarProduct(v1, dir) <= 0) {
      dis = (v1.x * v1.x) + (v1.y * v1.y);
      return (dis <= (radius * radius));
    }
    if (ScalarProduct(v2, dir) >= 0) {
      dis = (v2.x * v2.x) + (v2.y * v2.y);
      return (dis <= (radius * radius));
    }
    Line l(s.p1, s.p2);
    int64_t verh = l.a * centre.x + l.b * centre.y + l.c;
    verh *= verh;
    int64_t nyz = (l.a * l.a) + (l.b * l.b);
    return (verh <= (nyz * (radius * radius)));
  }

  Point::~Point() = default;

  Segment::~Segment() = default;

  Ray::~Ray() = default;

  Line::~Line() = default;

  Polygon::~Polygon() = default;

  Circle::~Circle() = default;
}