#ifndef RAY_H
#define RAY_H
#include "ishape.h"
namespace geometry {
  class Ray : public IShape {
  public:
    Point begin;
    Vector direct;
    Ray();
    Ray(const Point&, const Point&);
    Ray(const Point&, const Vector&);
    ~Ray() override;
    Ray& Move(const Vector&) override;
    Ray* Clone() const override;
    std::string ToString() const override;
    bool ContainsPoint(const Point&) const override;
    bool CrossesSegment(const Segment&) const override;
  }; 
}

#endif
