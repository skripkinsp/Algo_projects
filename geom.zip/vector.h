#ifndef VECTOR_H
#define VECTOR_H
#include "ishape.h"
namespace geometry{
  class Vector {
   public:
    int x;
    int y;
    Vector();
    Vector(int, int);
    Vector(const Point&, const Point&);
    Vector operator+(const Vector&);
    Vector operator-(const Vector&);
    Vector operator+();
    Vector operator-();
    Vector& operator+=(const Vector&);
    Vector& operator-=(const Vector&);
    Vector& operator*=(int);
    Vector& operator/=(int);
    Vector operator*(int);
    Vector operator/(int);
    std::string ToString() const;
    Vector& operator=(const Vector&);
  };
}
#endif