#ifndef CIRCLE_H
#define CIRCLE_H
#include "ishape.h"
namespace geometry {
  class Circle : public IShape {
  public:
    int radius = 0;
    Point centre;
    Circle();
    Circle(const Point&, int);
    ~Circle() override;
    Circle& Move(const Vector&) override;
    Circle* Clone() const override;
    std::string ToString() const override;
    bool ContainsPoint(const Point&) const override;
    bool CrossesSegment(const Segment&) const override;
    bool OnAreol(const Point&) const;
  };
}
#endif