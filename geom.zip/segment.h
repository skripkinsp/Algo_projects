#ifndef SEGMENT_H
#define SEGMENT_H
#include "ishape.h"
namespace geometry{
  class Segment : public IShape{
  public:
    Point p1;
    Point p2;
    Segment();
    Segment(Point, Point);
    ~Segment() override;
    Segment* Clone() const override;
    Segment& Move(const Vector&) override;
    std::string ToString() const override;
    bool ContainsPoint(const Point&) const override;
    bool CrossesSegment(const Segment&) const override;
  };
}

#endif