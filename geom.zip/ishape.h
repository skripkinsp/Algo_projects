#ifndef ISHAPE_H
#define ISHAPE_H
#include <string>

namespace geometry {
  class Point;
  class Vector;
  class Segment;
  class Ray;
  class Line;
  class Polygon;
  class IShape {
  public:
    virtual IShape& Move(const Vector&) = 0;
    virtual bool ContainsPoint (const Point&) const = 0;
    virtual bool CrossesSegment(const Segment&) const = 0;
    virtual IShape* Clone() const = 0;
    virtual std::string ToString() const = 0;
    virtual ~IShape() = default;
  };
  int64_t VectorProduct(const Vector&, const Vector&);
  int64_t ScalarProduct(const Vector&, const Vector&);
  bool IsParrallel(const Line&, const Line&);
  Point Cross(const Line&, const Line&);
  Vector operator-(const Point& a, const Point& b);
  Vector operator*(int, const Vector&);
  bool operator==(const Vector&, const Vector&);
  bool operator!=(const Vector&, const Vector&);
}

#endif