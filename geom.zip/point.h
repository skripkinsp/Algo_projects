#ifndef POINT_H
#define POINT_H
#include "ishape.h"
namespace geometry{
  class Point : public IShape {
  public:
    int x;
    int y;
    Point();
    Point(int, int);
    ~Point() override;
    bool ContainsPoint (const Point&) const override;
    bool CrossesSegment(const Segment&) const override;
    Point& Move(const Vector&) override;
    Point* Clone() const override;
    std::string ToString() const override;
  };
}

#endif