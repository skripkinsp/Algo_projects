#pragma once

#include <stdexcept>
#include <algorithm>

class RationalDivisionByZero : public std::runtime_error {
 public:
  RationalDivisionByZero() : std::runtime_error("RationalDivisionByZero") {
  }
};

class Rational {
  int64_t num_;
  int64_t den_;

 public:
  Rational() : num_(0), den_(1) {
  }

  Rational(int64_t n, int64_t d) : num_(n), den_(d) {
    Division();
  }

  Rational(int64_t n) : num_(n) {  // NOLINT
    den_ = 1;
  }

  Rational(const Rational &) = default;

  ~Rational() = default;

  int64_t GetNumerator() const {
    return num_;
  }

  int64_t GetDenominator() const {
    return den_;
  }

  void Division();

  void SetNumerator(const int64_t &n);

  void SetDenominator(const int64_t &d);

  Rational &operator=(const Rational &another);

  Rational &operator+=(const Rational &another);

  Rational &operator-=(const Rational &another);

  Rational &operator*=(const Rational &another);

  Rational &operator/=(const Rational &another);

  friend Rational operator+(const Rational &l, const Rational &r);

  friend Rational operator-(const Rational &l, const Rational &r);

  friend Rational operator/(const Rational &l, const Rational &r);

  friend Rational operator*(const Rational &l, const Rational &r);

  Rational &operator++();

  Rational &operator--();

  Rational operator++(int);

  Rational operator--(int);

  friend bool operator<(const Rational &l, const Rational &r);

  friend bool operator>(const Rational &l, const Rational &r);

  friend bool operator==(const Rational &l, const Rational &r);

  friend bool operator<=(const Rational &l, const Rational &r);

  friend bool operator>=(const Rational &l, const Rational &r);

  friend bool operator!=(const Rational &l, const Rational &r);

  Rational operator-() const;

  Rational operator+() const;

  friend std::istream &operator>>(std::istream &is, Rational &rational);

  friend std::ostream &operator<<(std::ostream &os, const Rational &rational);
};
