#include <iostream>
#include "rational.h"

void Rational::Division() {
  if (den_ == 0) {
    throw RationalDivisionByZero{};
  }
  int64_t pr = std::__gcd(num_, den_);
  num_ /= pr;
  den_ /= pr;
  if (den_ < 0) {
    num_ *= -1;
    den_ *= -1;
  }
}

void Rational::SetNumerator(const int64_t &n) {
  num_ = n;
  Division();
}

void Rational::SetDenominator(const int64_t &d) {
  den_ = d;
  Division();
}

Rational &Rational::operator+=(const Rational &another) {
  den_ *= another.den_;
  num_ = num_ * another.den_ + another.num_ * den_;
  Division();
  return *this;
}

Rational &Rational::operator=(const Rational &another) {
  if (*this != another) {
    num_ = another.num_;
    den_ = another.den_;
  }
  return *this;
}

Rational &Rational::operator-=(const Rational &another) {
  den_ *= another.den_;
  num_ = num_ * another.den_ - another.num_ * den_;
  Division();
  return *this;
}

Rational &Rational::operator*=(const Rational &another) {
  num_ *= another.num_;
  den_ *= another.den_;
  Division();
  return *this;
}

Rational &Rational::operator/=(const Rational &another) {
  num_ *= another.den_;
  den_ *= another.num_;
  Division();
  return *this;
}

Rational operator+(const Rational &l, const Rational &r) {
  auto buf = l;
  return buf += r;
}

Rational operator-(const Rational &l, const Rational &r) {
  auto buf = l;
  return buf -= r;
}

Rational operator*(const Rational &l, const Rational &r) {
  auto buf = l;
  return buf *= r;
}

Rational operator/(const Rational &l, const Rational &r) {
  auto buf = l;
  return buf /= r;
}

Rational &Rational::operator++() {
  num_ += den_;
  Division();
  return *this;
}

Rational &Rational::operator--() {
  num_ -= den_;
  Division();
  return *this;
}

Rational Rational::operator++(int) {
  auto another = *this;
  num_ += den_;
  Division();
  return another;
}

Rational Rational::operator--(int) {
  auto another = *this;
  num_ -= den_;
  Division();
  return another;
}

bool operator<(const Rational &l, const Rational &r) {
  auto res = l - r;
  return res.num_ < 0;
}

bool operator>(const Rational &l, const Rational &r) {
  auto res = l - r;
  return res.num_ > 0;
}

bool operator>=(const Rational &l, const Rational &r) {
  return !(l < r);
}

bool operator<=(const Rational &l, const Rational &r) {
  return !(l > r);
}

bool operator==(const Rational &l, const Rational &r) {
  auto res = l - r;
  return res.num_ == 0;
}

bool operator!=(const Rational &l, const Rational &r) {
  auto res = l - r;
  return res.num_ != 0;
}

Rational Rational::operator-() const {
  auto copy = *this;
  copy.num_ = -num_;
  return copy;
}

Rational Rational::operator+() const {
  return *this;
}

std::istream &operator>>(std::istream &is, Rational &rational) {
  is >> rational.num_;
  if (is.peek() == '/') {
    is.ignore(1);
    is >> rational.den_;
  } else {
    rational.den_ = 1;
  }
  rational.Division();
  return is;
}

std::ostream &operator<<(std::ostream &os, const Rational &rational) {
  if (rational.den_ != 1) {
    os << rational.num_ << '/' << rational.den_;
    return os;
  }
  os << rational.num_;
  return os;
}